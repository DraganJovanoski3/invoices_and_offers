<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

require_once 'config/database.php';

// Handle delete form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $preinvoice_id = $_POST['preinvoice_id'];
    // Delete pre-invoice items first (due to foreign key constraint)
    $stmt = $pdo->prepare("DELETE FROM pre_invoice_items WHERE preinvoice_id = ?");
    $stmt->execute([$preinvoice_id]);
    // Delete the pre-invoice
    $stmt = $pdo->prepare("DELETE FROM pre_invoices WHERE id = ?");
    $stmt->execute([$preinvoice_id]);
    $success = "Про Фактурата е избришана успешно!";
}

// Get all pre-invoices with client information
$stmt = $pdo->query("
    SELECT pf.*, c.name as client_name
    FROM pre_invoices pf
    LEFT JOIN clients c ON pf.client_id = c.id
    ORDER BY pf.created_at DESC
");
$preinvoices = $stmt->fetchAll();

// Get company settings for currency
$stmt = $pdo->prepare("SELECT currency FROM company_settings WHERE id = 1");
$stmt->execute();
$company = $stmt->fetch();
$currency = $company['currency'] ?? 'ден';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Про Фактури - Invoicing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .main-content {
            flex: 1;
        }
        footer {
            margin-top: auto;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <?php
            $logo_path = '/uploads/company_logo.png';
            $upload_dir = __DIR__ . '/uploads/';
            $logo_files = glob($upload_dir . 'company_logo*.png');
            if ($logo_files && count($logo_files) > 0) {
                $logo_path = '/uploads/' . basename($logo_files[0]);
            }
            ?>
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="<?php echo $logo_path; ?>" alt="DDS Logo" style="height:32px; width:auto; margin-right:10px;">
                Фактури и Понуди
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Почетна</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="invoices.php">Фактури</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="offers.php">Понуди</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="preinvoices.php">Про Фактури</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="clients.php">Клиенти</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="services.php">Услуги</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="company_settings.php">Поставки</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Одјава</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-4 main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Про Фактури</h2>
            <a href="create_preinvoice.php" class="btn btn-primary">
                <i class="bi bi-plus"></i> Нова Про Фактура
            </a>
        </div>
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Број</th>
                                <th>Клиент</th>
                                <th>Датум на издавање</th>
                                <th>Датум на доспевање</th>
                                <th>Износ</th>
                                <th>Тип на плаќање</th>
                                <th>Статус</th>
                                <th>Дејства</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($preinvoices as $pf): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($pf['preinvoice_number']); ?></td>
                                    <td><?php echo htmlspecialchars($pf['client_name']); ?></td>
                                    <td><?php echo date('d.m.Y', strtotime($pf['issue_date'])); ?></td>
                                    <td><?php echo date('d.m.Y', strtotime($pf['due_date'])); ?></td>
                                    <td><?php echo number_format($pf['total_amount'], 2); ?> <?php echo $currency; ?></td>
                                    <td><?php echo $pf['payment_type'] === 'advance' ? 'Аванс' : 'Целосно'; ?></td>
                                    <td>
                                        <?php
                                        $status_map = [
                                            'draft' => 'Нацрт',
                                            'sent' => 'Испратена',
                                            'paid' => 'Платена',
                                            'cancelled' => 'Откажана'
                                        ];
                                        echo isset($status_map[$pf['status']]) ? $status_map[$pf['status']] : htmlspecialchars($pf['status']);
                                        ?>
                                    </td>
                                    <td>
                                        <a href="view_preinvoice.php?id=<?php echo $pf['id']; ?>" class="btn btn-sm btn-outline-primary">Види</a>
                                        <a href="edit_preinvoice.php?id=<?php echo $pf['id']; ?>" class="btn btn-sm btn-outline-warning">Уреди</a>
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Дали сте сигурни дека сакате да ја избришете Про Фактурата?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="preinvoice_id" value="<?php echo $pf['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">Избриши</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (empty($preinvoices)): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted">Нема додадени Про Фактури.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <footer class="bg-dark mt-5 py-3">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <p class="mb-0" style="color: #38BDF8;">Custom Invoicing System made by <strong><a href="https://ddsolutions.com.mk/" target="_blank" style="color: #38BDF8; text-decoration: none;">DDSolutions</a></strong></p>
                </div>
            </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 